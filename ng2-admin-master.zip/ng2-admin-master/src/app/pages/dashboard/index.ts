export * from './dashboard.component';
