import {Component} from '@angular/core';


@Component({
  selector: 'flat-buttons',
  templateUrl: './flatButtons.html',
})
export class FlatButtons {

  constructor() {
  }
}
