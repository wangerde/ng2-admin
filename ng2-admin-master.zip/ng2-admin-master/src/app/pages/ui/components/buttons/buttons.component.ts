import {Component} from '@angular/core';

@Component({
  selector: 'buttons',
  templateUrl: './buttons.html',
  styleUrls: ['./buttons.scss']
})
export class Buttons {

  constructor() {
  }
}
