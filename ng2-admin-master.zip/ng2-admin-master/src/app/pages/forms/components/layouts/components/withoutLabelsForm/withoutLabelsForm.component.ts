import {Component} from '@angular/core';

@Component({
  selector: 'without-labels-form',
  templateUrl: './withoutLabelsForm.html',
})
export class WithoutLabelsForm {

  constructor() {
  }
}
