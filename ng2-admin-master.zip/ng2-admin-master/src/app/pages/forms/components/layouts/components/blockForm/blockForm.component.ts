import {Component} from '@angular/core';

@Component({
  selector: 'block-form',
  templateUrl: './blockForm.html',
})
export class BlockForm {

  constructor() {
  }
}
