export * from './basicTables.component';
