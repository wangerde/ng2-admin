import {Component} from '@angular/core';

@Component({
  selector: 'basic-tables',
  templateUrl: './basicTables.html',
  styleUrls: ['./basicTables.scss']

})
export class BasicTables {

  constructor() {
  }
}
