export * from './borderedTable.component';
